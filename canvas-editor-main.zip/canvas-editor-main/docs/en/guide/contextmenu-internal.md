# Internal Contextmenu

## Global

- Cut
- Copy
- Paste
- Select all
- Print

## Hyperlinks

- Delete the link
- Unlink
- Edit the link

## Image

- Change the picture
- Save as picture
- Text wrapping
  - Embedded
  - Upper and lower surrounding
  - Float above text
  - Float below text

## Table

- Table borders
- All borders
- Borderless
- Outer border
- Td borders
  - Top border
  - Right border
  - Bottom border
  - Left border
  - Forward border
  - Back border
- Vertical alignment
- Top alignment
- Center vertically
- Bottom end alignment
- Insert rows and columns
- Insert 1 row above
- Insert 1 row below
- Insert 1 column on the left
- Insert 1 column on the right side
- Delete rows and columns
- Delete 1 row
- Remove 1 column
- Delete the entire table
- Merge cells
- Cancel the merge

## control

- Delete the control
