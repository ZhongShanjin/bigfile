export interface IPlaceholder {
  data: string
  color?: string
  opacity?: number
  size?: number
  font?: string
}
