export interface IGroup {
  opacity?: number
  backgroundColor?: string
  activeOpacity?: number
  activeBackgroundColor?: string
  disabled?: boolean
}
