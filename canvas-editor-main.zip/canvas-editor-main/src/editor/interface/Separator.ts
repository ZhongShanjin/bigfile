export interface ISeparatorOption {
  strokeStyle?: string
  lineWidth?: number
}
