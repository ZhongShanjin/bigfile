import { MaxHeightRatio } from '../dataset/enum/Common'

export interface IFooter {
  bottom?: number
  maxHeightRadio?: MaxHeightRatio
  disabled?: boolean
}
