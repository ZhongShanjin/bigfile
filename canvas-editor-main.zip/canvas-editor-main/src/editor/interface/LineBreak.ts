export interface ILineBreakOption {
  disabled?: boolean
  color?: string
  lineWidth?: number
}
