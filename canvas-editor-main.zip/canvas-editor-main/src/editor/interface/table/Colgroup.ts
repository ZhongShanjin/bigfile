export interface IColgroup {
  id?: string
  width: number
}
