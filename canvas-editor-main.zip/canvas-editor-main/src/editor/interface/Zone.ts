export interface IZoneOption {
  tipDisabled?: boolean
}
