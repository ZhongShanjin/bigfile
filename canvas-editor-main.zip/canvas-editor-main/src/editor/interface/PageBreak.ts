export interface IPageBreak {
  font?: string
  fontSize?: number
  lineDash?: number[]
}
