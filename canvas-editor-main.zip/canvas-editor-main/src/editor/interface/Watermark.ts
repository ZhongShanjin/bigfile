export interface IWatermark {
  data: string
  color?: string
  opacity?: number
  size?: number
  font?: string
}
