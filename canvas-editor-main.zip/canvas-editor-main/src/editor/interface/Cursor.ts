export interface ICursorOption {
  width?: number
  color?: string
  dragWidth?: number
  dragColor?: string
}
