export enum RowFlex {
  LEFT = 'left',
  CENTER = 'center',
  RIGHT = 'right',
  ALIGNMENT = 'alignment',
  JUSTIFY = 'justify'
}
