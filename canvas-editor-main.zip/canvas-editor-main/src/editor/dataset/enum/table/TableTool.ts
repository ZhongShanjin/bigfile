export enum TableOrder {
  ROW = 'row',
  COL = 'col'
}
