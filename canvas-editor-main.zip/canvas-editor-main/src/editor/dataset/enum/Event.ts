export enum MouseEventButton {
  LEFT = 0,
  CENTER = 1,
  RIGHT = 2
}
