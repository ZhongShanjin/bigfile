export enum TextDecorationStyle {
  SOLID = 'solid',
  DOUBLE = 'double',
  DASHED = 'dashed',
  DOTTED = 'dotted',
  WAVY = 'wavy'
}

export enum DashType {
  SOLID = 'solid',
  DASHED = 'dashed',
  DOTTED = 'dotted'
}
