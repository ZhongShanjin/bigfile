export enum MoveDirection {
  UP = 'top',
  DOWN = 'down',
  LEFT = 'left',
  RIGHT = 'right'
}
