export enum BlockType {
  IFRAME = 'iframe',
  VIDEO = 'video'
}
