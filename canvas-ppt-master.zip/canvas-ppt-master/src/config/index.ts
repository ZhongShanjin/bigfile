export const defaultImageSrc = new URL("@/assets/images/imageView.png", import.meta.url).href;

export const defaultAudioSrc = new URL("@/assets/images/audioView.png", import.meta.url).href;
