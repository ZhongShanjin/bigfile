// ppt编辑操作

export enum OPTION_TYPE {
    INIT_DB_SLIDE = "INIT_DB_SLIDE", // 初始化db数据
    APPLY_BACKGROUND_ALL = "APPLY_BACKGROUND_ALL", // 应用背景到全部
    ADD_EMPTY_SLIDE = "ADD_EMPTY_SLIDE", // 新增页面
    PASTE_SLIDE = "PASTE_SLIDE", // 粘贴页面
    DELETE_SLIDE = "DELETE_SLIDE", // 删除页面
    SORT_SLIDE = "SORT_SLIDE", // 页面排序
}
