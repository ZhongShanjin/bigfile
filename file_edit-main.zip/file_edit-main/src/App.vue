<template>
  <!-- <EditorAm msg="Vite + Vue" /> -->
  <router-view />
</template>
<script setup lang="ts">
// import EditorAm from './components/editorAm/index.vue'
</script>

<style scoped>

</style>
