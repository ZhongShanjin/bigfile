import ModuleList from './moduleList.vue';
import ModuleSetting from './moduleSetting.vue';
import pageHeader from './pageHeader.vue';

export { ModuleList,ModuleSetting,pageHeader };