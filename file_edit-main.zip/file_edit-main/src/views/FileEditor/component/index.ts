import ModuleList from './moduleList.vue';
import ModuleSetting from './moduleSetting.vue';

export { ModuleList,ModuleSetting };