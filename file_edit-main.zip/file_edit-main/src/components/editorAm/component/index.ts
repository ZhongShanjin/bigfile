import ModuleList from './moduleList.vue';

export { ModuleList };