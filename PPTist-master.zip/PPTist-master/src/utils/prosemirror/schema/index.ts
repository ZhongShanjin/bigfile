import nodes from './nodes'
import marks from './marks'

export const schemaNodes = nodes
export const schemaMarks = marks
