import { hfmath, CONFIG as hfmathConfig } from 'hfmath'

hfmathConfig.SUB_SUP_SCALE = 0.5

export { hfmath }