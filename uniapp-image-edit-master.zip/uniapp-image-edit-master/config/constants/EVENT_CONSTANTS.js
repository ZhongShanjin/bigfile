export default {
	// 隐藏tabbar
	GLOBAL_HIDE_TABBAR: 'GLOBAL_HIDE_TABBAR'
}