export default {
  esm: 'rollup',
  cjs: 'rollup',
};
