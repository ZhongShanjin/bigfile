/**
 * Created by yeanzhi on 17/2/7.
 */
'use strict';
import FabricPhoto from './src/index.js';
export default FabricPhoto;
