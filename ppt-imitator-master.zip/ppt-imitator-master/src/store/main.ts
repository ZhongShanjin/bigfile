import { customAlphabet } from 'nanoid'
import { defineStore } from 'pinia'
import { CreatingElement, TextFormatPainter } from '@/types/edit'
import { ToolbarStates } from '@/types/toolbar'
import { DialogForExportTypes } from '@/types/export'
import { SYS_FONTS } from '@/configs/font'
import { TextAttrs, defaultRichTextAttrs } from '@/utils/prosemirror/utils'
import { isSupportFont } from '@/utils/font'
import { useSlidesStore } from './slides'

export interface MainState {
  activeElementIdList: string[]
  handleElementId: string
  activeGroupElementId: string
  hiddenElementIdList: string[]
  canvasPercentage: number
  canvasScale: number
  canvasDragged: boolean
  thumbnailsFocus: boolean
  editorAreaFocus: boolean
  disableHotkeys: boolean
  gridLineSize: number
  showRuler: boolean
  creatingElement: CreatingElement | null
  availableFonts: typeof SYS_FONTS
  toolbarState: ToolbarStates
  clipingImageElementId: string
  isScaling: boolean
  richTextAttrs: TextAttrs
  selectedTableCells: string[]
  selectedSlidesIndex: number[]
  dialogForExport: DialogForExportTypes
  databaseId: string
  textFormatPainter: TextFormatPainter | null
  showSelectPanel: boolean
}

const nanoid = customAlphabet('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
export const databaseId = nanoid(10)


export const useMainStore = defineStore('main', {
  state: (): MainState => ({
    activeElementIdList: [], // 被选中的元素ID集合，包含 handleElementId
    handleElementId: '', // 正在操作的元素ID
    activeGroupElementId: '', // 组合元素成员中，被选中可独立操作的元素ID
    hiddenElementIdList: [], // 被隐藏的元素ID集合
    canvasPercentage: 90, // 画布可视区域百分比
    canvasScale: 1, // 画布缩放比例（基于宽度1000px）
    canvasDragged: false, // 画布被拖拽移动
    thumbnailsFocus: false, // 左侧导航缩略图聚焦
    editorAreaFocus: false, // 编辑区域聚焦
    disableHotkeys: false, // 禁用快捷键
    gridLineSize: 0, // 网格线尺寸（0表示不显示网格线）
    showRuler: false, // 显示标尺
    creatingElement: null, // 正在插入的元素信息，需要通过绘制插入的元素（文字、形状、线条）
    availableFonts: SYS_FONTS, // 当前环境可用字体
    toolbarState: ToolbarStates.SLIDE_DESIGN, // 右侧工具栏状态
    clipingImageElementId: '', // 当前正在裁剪的图片ID、
    richTextAttrs: defaultRichTextAttrs, // 富文本状态
    selectedTableCells: [], // 选中的表格单元格
    isScaling: false, // 正在进行元素缩放
    selectedSlidesIndex: [], // 当前被选中的页面索引集合
    dialogForExport: '', // 导出面板
    databaseId, // 标识当前应用的indexedDB数据库ID
    textFormatPainter: null, // 文字格式刷
    showSelectPanel: false, // 打开选择面板
  }),
  getters: {
    canvasScalePercentage(state) {
      // Math.round() 函数返回一个数字四舍五入后最接近的整数
      return Math.round(state.canvasScale * 100) + '%'
    },
    activeElementList(state) {
      const slidesStore = useSlidesStore()
      const currentSlide = slidesStore.currentSlide
      if (!currentSlide || !currentSlide.elements) return []
      return currentSlide.elements.filter(element => state.activeElementIdList.includes(element.id))
    },
    handleElement(state) {
      const slidesStore = useSlidesStore()
      const currentSlide = slidesStore.currentSlide
      if (!currentSlide || !currentSlide.elements) return null
      return currentSlide.elements.find(element => state.handleElementId === element.id) || null
    }
  },
  actions: {
    // 设置处于选中状态的元素ID列表
    setActiveElementIdList(activeElementIdList: string[]) {
      if (activeElementIdList.length === 1)
        this.handleElementId = activeElementIdList[0]
      else this.handleElementId = ''
      this.activeElementIdList = activeElementIdList
    },
    // 设置左侧缩略图聚焦
    setThumbnailsFocus(isFocus: boolean) {
      this.thumbnailsFocus = isFocus
    },
    setAvailableFonts() {
      this.availableFonts = SYS_FONTS.filter(font => isSupportFont(font.value))
    },
    // 更新被选中的页面索引集合
    updateSelectedSlidesIndex(selectedSlidesIndex: number[]) {
      this.selectedSlidesIndex = selectedSlidesIndex
    },
    // 设置正在插入的元素
    setCreatingElement(element: CreatingElement | null) {
      this.creatingElement = element
    },
    // 设置编辑区聚焦与否
    setEditorAreaFocus(isFocus: boolean) {
      this.editorAreaFocus = isFocus
    },
    setCanvasPercentage(percentage: number) {
      this.canvasPercentage = percentage
    },
    setCanvasDragged(isDragged: boolean) {
      this.canvasDragged = isDragged
    },
    setCanvasScale(scale: number) {
      this.canvasScale = scale
    },
    // 设置文字格式刷
    setTextFormatPainter(textFormatPainter: TextFormatPainter | null) {
      this.textFormatPainter = textFormatPainter
    },
    // 设置选择面板
    setSelectPanelState(show: boolean) {
      this.showSelectPanel = show
    },
    setGridLineSize(size: number) {
      this.gridLineSize = size
    },
    setRulerState(show: boolean) {
      this.showRuler = show
    },
    setHandleElementId(handleElementId: string) {
      this.handleElementId = handleElementId
    },
    setActiveGroupElementId(activeGroupElementId: string) {
      this.activeGroupElementId = activeGroupElementId
    },
    setDisableHotkeysState(disable: boolean) {
      this.disableHotkeys = disable
    },
    setSelectedTableCells(cells: string[]) {
      this.selectedTableCells = cells
    },
    setRichtextAttrs(attrs: TextAttrs) {
      this.richTextAttrs = attrs
    },
    setClipingImageElementId(elId: string) {
      this.clipingImageElementId = elId
    },
    setScalingState(isScaling: boolean) {
      this.isScaling = isScaling
    },
    setToolbarState(toolbarState: ToolbarStates) {
      this.toolbarState = toolbarState
    },
    setHiddenElementIdList(hiddenElementIdList: string[]) {
      this.hiddenElementIdList = hiddenElementIdList
    },
    setDialogForExport(type: DialogForExportTypes) {
      this.dialogForExport = type
    },
  }
})
