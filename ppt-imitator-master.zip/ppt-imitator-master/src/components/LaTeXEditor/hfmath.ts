// hfmath是一个用于呈现数学公式的JavaScript工具，可以将LaTeX转换为SVG路径展示数学公式。在使用hfmath之前，需要了解一些基本的LaTeX公式语法。
import { hfmath, CONFIG as hfmathConfig } from "hfmath"

hfmathConfig.SUB_SUP_SCALE = 0.5
export { hfmath }