import { useMainStore } from "@/store/main"
import { useSlidesStore } from "@/store/slides"
import { PPTElement, Slide } from "@/types/slides"
import { createElementIdMap, createSlideMap } from "@/utils/element"
import { nanoid } from "nanoid"
import { storeToRefs } from "pinia"
import useHistorySnapshot from "./useHistorySnapshot"

export default () => {
  const { addHistorySnapshot } = useHistorySnapshot()
  const mainStore = useMainStore()

  const slidesStore = useSlidesStore()
  const { currentSlide } = storeToRefs(slidesStore)

  /**
   * 添加指定的元素数据（一组）
   * @param elements 元素列表数据
   */
  const addElementsFromData = (elements: PPTElement[]) => {
    const { groupIdMap, elIdMap } = createElementIdMap(elements)
    // 收集当前页面的元素id
    const currentSlideElementIdList = currentSlide.value.elements.map(el => el.id)

    for (const element of elements) {
      // 判断元素element的id是否与当前页面的元素id相同，相同则表示该element元素是由当前页面其中一个元素复制而来的
      const inCurrentSlide = currentSlideElementIdList.includes(element.id)
      // 为剪贴后的新元素分配id
      element.id = elIdMap[element.id]

      // 若为真，表示该element元素是由当前页面其中一个元素复制而来的，新元素则基于原来的元素left、top距离各+10
      if (inCurrentSlide) {
        element.left = element.left + 10
        element.top = element.top + 10
      }
      if (element.groupId) element.groupId = groupIdMap[element.groupId]
    }

    slidesStore.addElement(elements)
    /**
     * Object.values()：一个包含对象自身的所有可枚举属性值的数组。
     * Object.values(elIdMap)：返回由elIdMap对象中的属性值（粘贴出来新元素的id）组成的数组
     */
    mainStore.setActiveElementIdList(Object.values(elIdMap))
    addHistorySnapshot()
  }

  /**
   * 添加指定的页面数据
   * @param slide 页面数据
   */
  const addSlidesFromData = (slides: Slide[]) => {
    const slideIdMap = createSlideMap(slides)

    const newSlides = slides.map(slide => {
      const { groupIdMap, elIdMap } = createElementIdMap(slide.elements)
      for (const element of slide.elements) {
        element.id = elIdMap[element.id]
        if (element.groupId) element.groupId = groupIdMap[element.groupId]

        // 若元素绑定了页面跳转链接
        if (element.link && element.link.type === 'slide') {
          // 待添加页面中包含该页面（至少两张），则替换相关绑定关系
          if (slideIdMap[element.link.target]) {
            element.link.target = slideIdMap[element.link.target]
          }
          // 待添加页面中不包含该页面，则删除该元素绑定的页面跳转
          else delete element.link
        }
      }

      // 动画id替换
      if (slide.animations) {
        for (const animation of slide.animations) {
          animation.id = nanoid(10)
          // 将 旧元素的动画 复制给 新的元素
          animation.elId = elIdMap[animation.elId]
        }
      }
      return {
        ...slide,
        id: slideIdMap[slide.id]
      }
    })
    slidesStore.addSlide(newSlides)
    addHistorySnapshot()
  }
  return {
    addElementsFromData,
    addSlidesFromData
  }
}