import { useMainStore } from "@/store/main"
import { storeToRefs } from "pinia"
import usePasteTextClipboardData from "./usePasteTextClipboardData"
import useDeleteElement from "./useDeleteElement"
import { encrypt } from "@/utils/crypto"
import { copyText, readClipboard } from '@/utils/clipboard'
import { message } from 'ant-design-vue'

export default () => {
  const mainStore = useMainStore()
  const { activeElementIdList, activeElementList } = storeToRefs(mainStore)

  const { pasteTextClipboardData } = usePasteTextClipboardData()
  const { deleteElement } = useDeleteElement()

  // 将选中元素数据加密后复制到剪贴板
  const copyElement = () => {
    if (!activeElementIdList.value.length) return
    // 将选中的元素数据进行加密
    const text = encrypt(JSON.stringify({
      type: 'elements',
      data: activeElementList.value
    }))
    // 加密后的元素数据复制到剪贴板
    copyText(text).then(() => {
      mainStore.setEditorAreaFocus(true)
    })
  }

  // 将选中元素复制后删除（剪切）
  const cutElement = () => {
    copyElement()
    deleteElement()
  }

  // 尝试将剪贴板元素数据解密后进行粘贴
  const pasteElement = () => {
    // 读取剪贴板的数据
    readClipboard()
      .then(text => {
        // 解析text的数据格式，根据解析结果选择合适的粘贴（直接在页面中呈现结果）
        pasteTextClipboardData(text)
      })
      .catch(err => message.warning(err))
  }

  // 将选中元素复制后立刻粘贴
  const quickCopyElement = () => {
    copyElement()
    pasteElement()
  }

  return {
    copyElement,
    cutElement,
    pasteElement,
    quickCopyElement,
  }
}