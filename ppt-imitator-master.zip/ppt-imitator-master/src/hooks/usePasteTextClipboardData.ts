import { pasteCustomClipboardString } from "@/utils/clipboard"
import useAddSlidesOrElements from "./useAddSlidesOrElements"
import { parseText2Paragraphs } from "@/utils/textParser"
import useCreateElement from "./useCreateElement"

interface PasteTextClipboardDataOptions {
  onlySlide?: boolean
  onlyElements?: boolean
}

export default () => {
  const { addElementsFromData, addSlidesFromData } = useAddSlidesOrElements()
  const { createTextElement } = useCreateElement()

  /**
 * 粘贴普通文本：创建为新的文本元素
 * @param text 文本
 */
  const createTextElementFromClipboard = (text: string) => {
    createTextElement({
      left: 0,
      top: 0,
      width: 600,
      height: 50
    }, { content: text })
  }

  /**
   * 解析剪贴板内容，根据解析结果选择合适的粘贴方式
   * @param text 剪贴板内容
   * @param options 配置项：onlySlide -- 仅处理页面粘贴；onlyElements -- 仅处理元素粘贴
   */
  const pasteTextClipboardData = (text: string, options?: PasteTextClipboardDataOptions) => {
    const onlySlide = options?.onlySlide || false
    const onlyElements = options?.onlyElements || false

    /**
     * 解析剪贴板字符串
     * 若为元素或者页面：将剪贴板的JSON字符串解析成JSON格式
     * 若为普通文本：则无需解析 
     */
    const clipboardData = pasteCustomClipboardString(text)

    // 元素或者页面
    if (typeof clipboardData === 'object') {
      const { type, data } = clipboardData
      // 仅仅是元素
      if (type === 'elements' && !onlySlide) addElementsFromData(data)
      // 仅仅是页面
      else if (type === 'slides' && !onlyElements) addSlidesFromData(data)
    }

    // 普通文本
    else if (!onlyElements && !onlySlide) {
      // 将数据解析为HTML字符串
      const string = parseText2Paragraphs(clipboardData)
      // 创建text元素
      createTextElementFromClipboard(string)
    }
  }

  return {
    pasteTextClipboardData
  }
}