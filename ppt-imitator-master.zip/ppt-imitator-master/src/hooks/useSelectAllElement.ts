import { useMainStore } from "@/store/main"
import { useSlidesStore } from "@/store/slides"
import { storeToRefs } from "pinia"

export default () => {
  const mainStore = useMainStore()
  const { currentSlide } = storeToRefs(useSlidesStore())
  const { hiddenElementIdList } = storeToRefs(mainStore)

  // 将当前页面全部元素设置为 选中状态
  const selectAllElement = () => {
    const unlockedElements = currentSlide.value.elements.filter(el =>
      !el.lock && !hiddenElementIdList.value.includes(el.id))
    const newActiveElementIdList = unlockedElements.map(el => el.id)
    mainStore.setActiveElementIdList(newActiveElementIdList)
  }

  return {
    selectAllElement
  }
}