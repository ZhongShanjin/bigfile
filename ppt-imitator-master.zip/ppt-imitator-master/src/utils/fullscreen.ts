// 进入全屏
export const enterFullscreen = () => {
  const docElm = document.documentElement
  if (docElm.requestFullscreen) docElm.requestFullscreen()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  else if ((docElm as any).mozRequestFullScreen) (docElm as any).mozRequestFullScreen()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  else if ((docElm as any).webkitRequestFullScreen) (docElm as any).webkitRequestFullScreen()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  else if ((docElm as any).msRequestFullscreen) (docElm as any).msRequestFullscreen()
}

// 退出全屏
export const exitFullscreen = () => {
  if (document.exitFullscreen) document.exitFullscreen()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  else if ((document as any).mozCancelFullScreen) (document as any).mozCancelFullScreen()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  else if ((document as any).webkitExitFullscreen) (document as any).webkitExitFullscreen()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  else if ((document as any).msExitFullscreen) (document as any).msExitFullscreen()
}

// 判断是否全屏
export const isFullscreen = () => {
  const fullscreenElement =
    document.fullscreenElement ||
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (document as any).mozFullScreenElement ||
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (document as any).webkitFullscreenElement ||
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (document as any).msFullscreenElement ||
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (document as any).webkitCurrentFullScreenElement
  return !!fullscreenElement
}