/**
 * 将普通文本转为带段落信息的HTML字符串
 * @param text 文本
 */
export const parseText2Paragraphs = (text: string) => {
  // 全局替换\n\r，并将其替换为<br>标签
  const htmlText = text.replace(/[\n\r]+/g, '<br>')
  // 以标签<br>为分隔符，返回一个数组
  const paragraphs = htmlText.split('<br>')
  let string = ''
  for (const paragraph of paragraphs) {
    // 去除paragraph为空的清空
    if (paragraph) string += `<div>${paragraph}</div>`
  }
  // string为HTML字符串
  return string
}