/**
 * 判断操作系统是否存在某字体
 * @param fontName 字体名
 */
export const isSupportFont = (fontName: string) => {
  if (typeof fontName !== 'string') return false

  const arial = 'Arial'
  if (fontName.toLowerCase() === arial.toLowerCase()) return true

  const size = 100
  const width = 100
  const height = 100
  const str = 'a'

  const canvas = document.createElement('canvas')
  const ctx = canvas.getContext('2d')

  if (!ctx) return false

  canvas.width = width
  canvas.height = height
  ctx.textAlign = 'center'
  ctx.fillStyle = 'black'
  ctx.textBaseline = 'middle'

  const getDotArray = (_fontFamily: string) => {
    // clearRect()在一个矩形区域内设置所有像素都是透明的
    ctx.clearRect(0, 0, width, height)
    ctx.font = `${size}px ${_fontFamily}, ${arial}`
    // fillText()使用当前的ctx.font值对文本进行渲染
    ctx.fillText(str, width / 2, height / 2)
    // getImageData()提取像素信息
    const imageData = ctx.getImageData(0, 0, width, height).data
    return [].slice.call(imageData).filter(item => item !== 0)
  }

  return getDotArray(arial).join('') !== getDotArray(fontName).join('')
}