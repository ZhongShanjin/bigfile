import { NodeType, Schema } from "prosemirror-model"
import { inputRules, wrappingInputRule, textblockTypeInputRule, smartQuotes, emDash, ellipsis } from "prosemirror-inputrules"

const blockQuoteRule = (nodeType: NodeType) => wrappingInputRule(/^\s*>\s$/, nodeType)

const orderedListRule = (nodeType: NodeType) => (
  // wrappingInputRule：接受一个特定于 schema 的参数，并创建一个特定于 schema 的输入规则
  wrappingInputRule(
    /^(\d+)\.\s$/,
    nodeType,
    match => ({ order: +match[1] }),
    (match, node) => node.childCount + node.attrs.order === +match[1],
  )
)

const bulletListRule = (nodeType: NodeType) => wrappingInputRule(/^\s*([-+*])\s$/, nodeType)
// textblockTypeInputRule：接受一个特定于 schema 的参数，并创建一个特定于 schema 的输入规则
const codeBlockRule = (nodeType: NodeType) => textblockTypeInputRule(/^```$/, nodeType)

export const buildInputRules = (schema: Schema) => {
  const rules = [
    ...smartQuotes, // 自动打开/关闭 单/双 引号相关的输入规则
    ellipsis, // 转换三个点为一个省略号的输入规则
    emDash, // 转换两个短斜杠为一个长破折号的输入规则
  ]
  rules.push(blockQuoteRule(schema.nodes.blockquote))
  rules.push(orderedListRule(schema.nodes.ordered_list))
  rules.push(bulletListRule(schema.nodes.bullet_list))
  rules.push(codeBlockRule(schema.nodes.code_block))
  
  // inputRules：创建一个输入规则插件。启用的话，将会导致与任何给定规则匹配的文本输入都会触发该规则对应的行为。
  return inputRules({ rules })
}