import { keymap } from 'prosemirror-keymap'
import { Schema } from 'prosemirror-model'
import { history } from 'prosemirror-history'
import { baseKeymap } from 'prosemirror-commands'
import { dropCursor } from 'prosemirror-dropcursor'
import { gapCursor } from 'prosemirror-gapcursor'

import { buildKeymap } from './keymap'
import { buildInputRules } from './inputrules'

export const buildPlugins = (schema: Schema) => {
  return [
    buildInputRules(schema),
    // keymap：用给定的绑定集合来创建一个按键映射插件
    keymap(buildKeymap(schema)),
    keymap(baseKeymap),
    dropCursor(),
    gapCursor(), // 创建一个 gap 光标插件
    // 返回一个插件以使编辑器撤销历史可用。该插件将会追踪撤销和重做的操作栈，这可以和 撤销 and 重做 命令一同使用
    history()
  ]
}