import { nanoid } from "nanoid"
import { PPTElement, PPTLineElement, Slide } from "@/types/slides"
import tinycolor from "tinycolor2"

interface RotatedElementData {
  left: number
  top: number
  width: number
  height: number
  rotate: number
}

/**
 * 以元素列表为基础，为每一个元素生成新的ID，并关联到旧ID形成一个字典
 * 主要用于复制元素时，维持数据中各处元素ID原有的关系
 * 例如：原本两个组合的元素拥有相同的groupId，复制后依然会拥有另一个相同的groupId
 * @param elements 元素列表数据
 */
export const createElementIdMap = (elements: PPTElement[]) => {
  const groupIdMap = {}
  const elIdMap = {}
  for (const element of elements) {
    const groupId = element.groupId
    // 确保 模板元素有groupId 且 groupIdMap中没有模板元素的groupId
    if (groupId && !groupIdMap[groupId]) {
      // 建立 以模板为基础的原有groupId 与 新元素groupId 之间的联系
      groupIdMap[groupId] = nanoid(10)
    }
    /**
     * 为每个新的元素生成id
     * 建立 以模板为基础的原有元素id 与 新元素id 之间的联系
     * Mpwv7x: "Gf5b5hwdAj"
     * WQOTAp: "somFwFdxNc"
     * vSheCJ: "fwv1NHesii"
     */
    elIdMap[element.id] = nanoid(10)
  }
  return {
    groupIdMap,
    elIdMap
  }
}

export const createSlideMap = (slides: Slide[]) => {
  const slideIdMap = {}
  for (const slide of slides) {
    slideIdMap[slide.id] = nanoid(10)
  }
  return slideIdMap
}

/**
 * 获取线条元素路径字符串
 * @param element 线条元素
 */
export const getLineElementPath = (element: PPTLineElement) => {
  // join()方法就是将array数据中每个元素都转为字符串，用自定义的连接符分割
  const start = element.start.join(',')
  const end = element.end.join(',')
  // broken：折线控制点位置（[x, y]）
  if (element.broken) {
    const mid = element.broken.join(',')
    return `M${start} L${mid} L${end}`
  }
  // curve：二次曲线控制点位置
  else if (element.curve) {
    const mid = element.curve.join(',')
    return `M${start} Q${mid} ${end}`
  }
  // cubic：三次曲线控制点位置
  else if (element.cubic) {
    const [c1, c2] = element.cubic
    const p1 = c1.join(',')
    const p2 = c2.join(',')
    return `M${start} C${p1} ${p2} ${end}`
  }
  // 直线
  return `M${start} L${end}`
}

/**
 * 根据表格的主题色，获取对应 用于配色的子颜色
 * @param themeColor 主题色
 */
export const getTableSubThemeColor = (themeColor: string) => {
  const rgba = tinycolor(themeColor)
  return [
    rgba.setAlpha(0.3).toRgbString(),
    rgba.setAlpha(0.1).toRgbString()
  ]
}

/**
 * 计算元素在画布中的矩形范围旋转后的新位置范围
 * @param element 元素的位置大小和旋转角度信息
 */
export const getRectRotatedRange = (element: RotatedElementData) => {
  const { left, top, width, height, rotate = 0 } = element
  // 以长方形为例，radius的值为对角线中点
  const radius = Math.sqrt(Math.pow(width, 2) + Math.pow(height, 2)) / 2

  const auxiliaryAngle = Math.atan(height / width) * 180 / Math.PI

  const tlbraRadian = (180 - rotate - auxiliaryAngle) * Math.PI / 180
  const trblaRadian = (auxiliaryAngle - rotate) * Math.PI / 180

  const middleLeft = left + width / 2
  const middleTop = top + height / 2

  const xAxis = [
    middleLeft + radius * Math.cos(tlbraRadian),
    middleLeft + radius * Math.cos(trblaRadian),
    middleLeft - radius * Math.cos(tlbraRadian),
    middleLeft - radius * Math.cos(trblaRadian),
  ]
  const yAxis = [
    middleTop - radius * Math.sin(tlbraRadian),
    middleTop - radius * Math.sin(trblaRadian),
    middleTop + radius * Math.sin(tlbraRadian),
    middleTop + radius * Math.sin(trblaRadian),
  ]

  return {
    xRange: [Math.min(...xAxis), Math.max(...xAxis)],
    yRange: [Math.min(...yAxis), Math.max(...yAxis)],
  }
}

/**
 * 计算元素在画布中的位置范围
 * @param element 元素信息
 */
export const getElementRange = (element: PPTElement) => {
  let minX, maxX, minY, maxY

  if (element.type === 'line') {
    // line元素中start[x, y] end[x, y]
    minX = element.left
    maxX = element.left + Math.max(element.start[0], element.end[0])
    minY = element.top
    maxY = element.top + Math.max(element.start[1], element.end[1])
  }
  else if ('rotate' in element && element.rotate) {
    const { left, top, width, height, rotate } = element
    const { xRange, yRange } = getRectRotatedRange({ left, top, width, height, rotate })
    minX = xRange[0]
    maxX = xRange[1]
    minY = yRange[0]
    maxY = yRange[1]
  }
  else {
    minX = element.left
    maxX = element.left + element.width
    minY = element.top
    maxY = element.top + element.height
  }
  return { minX, maxX, minY, maxY }
}

export interface AlignLine {
  value: number
  range: [number, number]
}

/**
 * 将一组对齐吸附线进行去重：同位置的多条对齐吸附线仅留下一条，取该位置所有对齐吸附线的最大值和最小值为新的范围
 * @param lines 一组对齐吸附线信息
 */
export const uniqAlignLines = (lines: AlignLine[]) => {
  const uniqLines: AlignLine[] = []
  lines.forEach(line => {
    // findIndex()返回数组中满足提供的测试函数的第一个元素的索引。若没有找到对应元素则返回 -1。
    const index = uniqLines.findIndex(_line => _line.value === line.value)
    if (index === -1) uniqLines.push(line)
    else {
      const uniqLine = uniqLines[index]
      const rangeMin = Math.min(uniqLine.range[0], line.range[0])
      const rangeMax = Math.max(uniqLine.range[1], line.range[1])
      const range: [number, number] = [rangeMin, rangeMax]
      const _line = { value: line.value, range }
      uniqLines[index] = _line
    }
  })
  return uniqLines
}

/**
 * 计算一组元素在画布中的位置范围
 * @param elementList 一组元素信息
 */
export const getElementListRange = (elementList: PPTElement[]) => {
  const leftValues: number[] = []
  const topValues: number[] = []
  const rightValues: number[] = []
  const bottomValues: number[] = []

  elementList.forEach(el => {
    // 收集每一个元素的最大最小值，并将其放入对应数组
    const { minX, maxX, minY, maxY } = getElementRange(el)
    leftValues.push(minX)
    topValues.push(minY)
    rightValues.push(maxX)
    bottomValues.push(maxY)
  })
  // 找出上述收集到的数据的最大最小值
  const minX = Math.min(...leftValues)
  const maxX = Math.max(...rightValues)
  const minY = Math.min(...topValues)
  const maxY = Math.max(...bottomValues)

  return { minX, maxX, minY, maxY }
}

/**
 * 计算元素在画布中的矩形范围旋转后的新位置与旋转之前位置的偏离距离
 * @param element 元素的位置大小和旋转角度信息
 */
export const getRectRotatedOffset = (element: RotatedElementData) => {
  const { xRange: originXRange, yRange: originYRange } = getRectRotatedRange({
    left: element.left,
    top: element.top,
    width: element.width,
    height: element.height,
    rotate: 0,
  })
  const { xRange: rotatedXRange, yRange: rotatedYRange } = getRectRotatedRange({
    left: element.left,
    top: element.top,
    width: element.width,
    height: element.height,
    rotate: element.rotate,
  })
  return {
    offsetX: rotatedXRange[0] - originXRange[0],
    offsetY: rotatedYRange[0] - originYRange[0],
  }
}