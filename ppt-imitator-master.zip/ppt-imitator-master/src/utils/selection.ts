// 清除文字选区
export const removeAllRanges = () => {
  // getSelection()：返回一个Selection对象，表示用户选择的文本范围或光标的当前位置
  const selection = window.getSelection()
  // 从选区中移除一个区域
  selection && selection.removeAllRanges()
}