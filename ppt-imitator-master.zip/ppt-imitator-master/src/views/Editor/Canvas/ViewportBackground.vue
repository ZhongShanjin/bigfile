<template>
  <div class="viewport-background" :style="backgroundStyle">
    <GridLines v-if="gridLineSize" />
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { storeToRefs } from 'pinia'
import { useMainStore } from '@/store/main'
import { useSlidesStore } from '@/store/slides'
import { SlideBackground } from '@/types/slides'
import useSlideBackgroundStyle from '@/hooks/useSlideBackgroundStyle'
import GridLines from './GridLines.vue'

const { gridLineSize } = storeToRefs(useMainStore())

const { currentSlide } = storeToRefs(useSlidesStore())
const background = computed<SlideBackground | undefined>(() => currentSlide.value?.background)
const { backgroundStyle } = useSlideBackgroundStyle(background)
</script>

<style lang="scss" scoped>
.viewport-background {
  width: 100%;
  height: 100%;
  background-position: center;
  position: absolute;
}
</style>