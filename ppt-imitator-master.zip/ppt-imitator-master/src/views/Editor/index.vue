<template>
  <div class="pptist-editor">
    <!-- 头部 -->
    <EditorHeader class="layout-header" />
    <div class="layout-content">
      <!-- 缩略图 -->
      <Thumbnails class="layout-content-left" />
      <div class="layout-content-center">
        <!-- 画布工具栏 -->
        <CanvasTool class="center-top" />
        <!-- 画布 -->
        <Canvas class="center-body" :style="{ height: `calc(100% - ${remarkHeight + 40}px)` }" />
        <!-- 备注 -->
        <Remark class="center-bottom" v-model:height="remarkHeight" :style="{ height: `${remarkHeight}px` }" />
      </div>
      <!-- 右侧工具栏 -->
      <Toolbar class="layout-content-right" />
    </div>
  </div>
  <!-- 选择面板 -->
  <SelectPanel v-if="showSelectPanel" />
  <!-- 文件->导出文件 中的对话框 -->
  <Modal :visible="!!dialogForExport" :footer="null" centered :closable="false" :width="680" destroyOnClose
    @cancel="closeExportDialog()">
    <!-- 导出对话框 -->
    <ExportDialog />
  </Modal>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { storeToRefs } from 'pinia'
import { useMainStore } from '@/store/main'
import useGlobalHotkey from '@/hooks/useGlobalHotkey'
import usePasteEvent from '@/hooks/usePasteEvent'

import EditorHeader from './EditorHeader/index.vue'
import Thumbnails from './Thumbnails/index.vue'
import CanvasTool from './CanvasTool/index.vue'
import Canvas from './Canvas/index.vue'
import Remark from './Remark/index.vue'
import Toolbar from './Toolbar/index.vue'
import SelectPanel from './SelectPanel.vue'
import ExportDialog from './ExportDialog/index.vue'
import { Modal } from 'ant-design-vue'

const remarkHeight = ref(40)

const mainStore = useMainStore()
const { dialogForExport, showSelectPanel } = storeToRefs(mainStore)
const closeExportDialog = () => mainStore.setDialogForExport('')

// 注册全局快捷键
useGlobalHotkey()
usePasteEvent()
</script>

<style lang="scss" scoped>
.pptist-editor {
  height: 100%;
}

.layout-header {
  height: 40px;
}

.layout-content {
  height: calc(100% - 40px);
  display: flex;
}

.layout-content-left {
  width: 160px;
  height: calc(100vh - 40px);
  flex-shrink: 0;
}

.layout-content-center {
  width: calc(100% - 160px - 260px);

  .center-top {
    height: 40px;
  }
}

.layout-content-right {
  width: 260px;
  height: 100%;
}
</style>