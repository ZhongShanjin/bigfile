<template>
  <div class="thumbnail-slide" :style="{
    width: size + 'px',
    height: size * viewportRatio + 'px'
  }">
    <div class="elements" :style="{
      width: VIEWPORT_SIZE + 'px',
      height: VIEWPORT_SIZE * viewportRatio + 'px',
      transform: `scale(${scale})` // 元素的缩放
    }" v-if="visible">
      <div class="background" :style="backgroundStyle"></div>
      <!-- 遍历循环slide中的elements -->
      <ThumbnailElement v-for="(element, index) in slide.elements" :key="element.id" :elementInfo="element"
        :elementIndex="index + 1" />
    </div>
    <div class="placeholder" v-else>加载中 ...</div>
  </div>
</template>

<script setup lang="ts">
import { PropType, computed, provide } from 'vue'
import { storeToRefs } from 'pinia'
import { Slide } from '@/types/slides'
import ThumbnailElement from './ThumbnailElement.vue'
import { VIEWPORT_SIZE } from '@/configs/canvas'
import { useSlidesStore } from '@/store/slides'
import { injectKeySlideScale } from '@/types/injectKey'
import useSlideBackgroundStyle from '@/hooks/useSlideBackgroundStyle'

// eslint-disable-next-line no-undef
const props = defineProps({
  slide: {
    // PropType<>：props声明时给一个prop标注更复杂的类型定义
    type: Object as PropType<Slide>,
    required: true
  },
  size: {
    type: Number,
    required: true
  },
  visible: {
    type: Boolean,
    default: true
  }
})

const { viewportRatio } = storeToRefs(useSlidesStore())

const background = computed(() => props.slide.background)
const { backgroundStyle } = useSlideBackgroundStyle(background)

const scale = computed(() => props.size / VIEWPORT_SIZE)
// provide：用于提供可以被后代组件注入的值
provide(injectKeySlideScale, scale)
</script>

<style lang="scss" scoped>
.thumbnail-slide {
  background-color: #fff;
  overflow: hidden;
  user-select: none;
}

.elements {
  transform-origin: 0 0;
}

.background {
  width: 100%;
  height: 100%;
  background-position: center;
  position: absolute;
}

.placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>