import { computed, Ref } from "vue"
import { TableCell } from "@/types/slides"

/**
 * 计算无效的单元格位置（被合并的单元格位置）集合
 * @param cells 表格单元格的数据
 */
export default (cells: Ref<TableCell[][]>) => {
  const hideCells = computed(() => {
    const hideCells = []

    // 遍历表格行数据
    for (let i = 0; i < cells.value.length; i++) {
      const rowCells = cells.value[i]
      // 遍历行数据的列数据
      for (let j = 0; j < rowCells.length; j++) {
        const cell = rowCells[j]
        /** 该单元格至少要合并一个单元格(单元格本身colspan或colrow)
         *  单元格列合并一个则colspan为2,单元格以左上单元格为主,其他被合并的单元格则隐藏
        */
        if (cell.colspan > 1 || cell.rowspan > 1) {
          for (let row = i; row < i + cell.rowspan; row++) {
            for (let col = row === i ? j + 1 : j; col < j + cell.colspan; col++) {
              hideCells.push(`${row}_${col}`)
            }
          }
        }
      }
    }
    return hideCells
  })
  return {
    hideCells
  }
}