<template>
  <div class="base-element-table" :style="{
    top: elementInfo.top + 'px',
    left: elementInfo.left + 'px',
    width: elementInfo.width + 'px'
  }">
    <div class="rotate-wrapper" :style="{ transform: `rotate(${elementInfo.rotate}deg)` }">
      <div class="element-content">
        <StaticTable :data="elementInfo.data" :width="elementInfo.width" :cellMinHeight="elementInfo.cellMinHeight"
          :colWidths="elementInfo.colWidths" :outline="elementInfo.outline" :theme="elementInfo.theme" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { PropType } from 'vue'
import { PPTTableElement } from '@/types/slides'
import StaticTable from './StaticTable.vue'

// eslint-disable-next-line no-undef
defineProps({
  elementInfo: {
    type: Object as PropType<PPTTableElement>,
    required: true
  }
})
</script>

<style lang="scss" scoped>
.base-element-table {
  position: absolute;
}

.rotate-wrapper {
  width: 100%;
  height: 100%;
}

.element-content {
  width: 100%;
  height: 100%;
  position: relative;
}
</style>