<template>
  <div class="custom-textarea" ref="textareaRef" @focus="handleFocus" @blur="handleBlur" @input="() => handleInput()"
    v-html="text">
  </div>
</template>

<script setup lang="ts">
import { defineProps, defineEmits, ref, watch, onUnmounted } from 'vue'
import { pasteCustomClipboardString, pasteExcelClipboardString } from '@/utils/clipboard'

const props = defineProps({
  value: {
    type: String,
    default: ''
  },
  contenteditable: {
    type: [Boolean, String],
    default: false
  }
})

const emit = defineEmits<{
  (event: 'updateValue', payload: string): void
  (event: 'insertExcelData', payload: string[][]): void
}>()

const textareaRef = ref<HTMLElement>()
const text = ref('')
const isFocus = ref(false)

// 自定义v-model，同步数据；当文本框聚焦时，不执行数据同步
watch(() => props.value, () => {
  if (isFocus.value) return
  text.value = props.value
  if (textareaRef.value) textareaRef.value.innerHTML = props.value
}, { immediate: true })

const handleInput = () => {
  if (!textareaRef.value) return
  const text = textareaRef.value.innerHTML
  emit('updateValue', text)
}

// 聚焦时更新焦点标记，并监听粘贴事件
const handleFocus = () => {
  isFocus.value = true

  if (!textareaRef.value) return
  // onpaste 属性用来获取或设置当前元素的paste事件的事件处理函数
  textareaRef.value.onpaste = (e: ClipboardEvent) => {
    e.preventDefault()
    if (!e.clipboardData) return

    const clipboardDataFirstItem = e.clipboardData.items[0]

    if (clipboardDataFirstItem && clipboardDataFirstItem.kind === 'string' && clipboardDataFirstItem.type === 'text/plain') {
      clipboardDataFirstItem.getAsString(text => {
        // 解析加密后的剪贴板内容，且此处只处理文字的粘贴
        const clipboardData = pasteCustomClipboardString(text)
        if (typeof clipboardData === 'object') return

        const excelData = pasteExcelClipboardString(text)
        if (excelData) {
          emit('insertExcelData', excelData)
          if (textareaRef.value) textareaRef.value.innerHTML = excelData[0][0]
          return
        }

        emit('updateValue', text)
        document.execCommand('insertText', false, text)
      })
    }
  }
}

// 失焦时更新焦点标记，清除粘贴事件监听
const handleBlur = () => {
  isFocus.value = false
  if (textareaRef.value) textareaRef.value.onpaste = null
}

// 清除粘贴事件监听
onUnmounted(() => {
  if (textareaRef.value) textareaRef.value.onpaste = null
})
</script>

<style lang="scss" scoped>
.custom-textarea {
  border: 0;
  outline: 0;
  -webkit-user-modify: read-write-plaintext-only;
  -moz-user-modify: read-write-plaintext-only;
}
</style>