# 1 实现思路

## 1.1 判断用户操作系统是否支持某字体

1. 实现原理：根据用户设置的字体**将某一个字符绘制在`canvas`上（`fillText()`）**，并**提取像素信息（`getImageData()`）**，然后和默认字体进行比对，如果**像素不一致，说明字体生效**；如果**像素完全一致，说明字体不生效**。

2. 代码实现

   ```ts
   export const isSupportFont = (fontName: string) => {
     if (typeof fontName !== 'string') return false
   
     const arial = 'Arial'
     if (fontName.toLowerCase() === arial.toLowerCase()) return true
   
     const size = 100
     const width = 100
     const height = 100
     const str = 'a'
   
     const canvas = document.createElement('canvas')
     const ctx = canvas.getContext('2d')
   
     if (!ctx) return false
   
     canvas.width = width
     canvas.height = height
     ctx.textAlign = 'center'
     ctx.fillStyle = 'black'
     ctx.textBaseline = 'middle'
   
     const getDotArray = (_fontFamily: string) => {
       // clearRect()在一个矩形区域内设置所有像素都是透明的
       ctx.clearRect(0, 0, width, height)
       ctx.font = `${size}px ${_fontFamily}, ${arial}`
       // fillText()使用当前的ctx.font值对文本进行渲染
       ctx.fillText(str, width / 2, height / 2)
       // getImageData()提取像素信息
       const imageData = ctx.getImageData(0, 0, width, height).data
       return [].slice.call(imageData).filter(item => item !== 0)
     }
   
     return getDotArray(arial).join('') !== getDotArray(fontName).join('')
   }
   ```

## 1.2 历史快照

1. 历史快照用于保存上一次操作的ppt里面的数据，使用**dexie第三方库**作为数据库进行对之前数据的保存，dexie作为比较成熟的IndexedDB库，存储方式是以数组的形式进行存储。
1. 当用户进行操作时，每操作一步，都往对应的表里面添加数据

## 1.3 右键自定义菜单

1. 知识点：右键自定义菜单的实现需要用到的知识点有：`自定义指令`，`创建虚拟DOM以及通过render函数进行渲染`。
2. 目的：使用自定义指令的目的不仅需要**取消鼠标右键的默认行为**，同时也需要**展示自己想要展示的菜单组件**。
3. 实现：在自定义指令的`onMounted`函数中，首先阻止鼠标右键出现的默认行为，其次利用`createVNode()`创建一个虚拟DOM，最后通过`render()`将虚拟DOM转换为真实DOM。
4. 细节：`createVNode()`需要接收两个参数，第一个是要右键需要展示的组件，第二个是要向组件传递的属性。`render()`需要接收两个参数，第一个是要被渲染的虚拟DOM，第二个是虚拟DOM的目标容器。

## 1.4 复制粘贴

1. **复制步骤**：首先使用`crypto-js`库将幻灯片或者元素的代码数据进行加密形成字符串，再使用`clipboard`库将该字符串复制到剪贴板。

2. **粘贴步骤**：使用浏览器的API`navigator.clipboard.readText()`来访问系统剪切板，以读取系统剪切板的内容；然后再利用`crypto-js`进行字符串的解密。**解密出来的数据需要进行判断**，以辨别其是幻灯片数据还是元素数据还是普通文本，若是普通文本则使用正则表达式转换成带有段落的HTML字符串，然后就添加到store里面的文字元素。

3. 复制文本到剪贴板和读取剪贴板都返回一个promise对象。

   复制文本到剪贴板：主要是为了**避免回调函数的信任问题，导致程序的控制反转**。而promise则可以将控制反转再反转回来，从而可以保证控制权还是在自己的程序。

   读取剪贴板：主要是为了方便程序的操作以及简洁。

4. 这里解密的操作用了一个巧妙的方法：

   ```js
   try {
     // 解密成功则代表text是元素或者页面（若不是JSON字符串会报错）
     clipboardData = JSON.parse(decrypt(text))
   }
   catch {
     // 解密失败则代表text是普通文本
     clipboardData = text
   }
   ```

## 1.5 元素组合

1. 组合当前选中的元素，并给它们赋予一个相同的分组ID。

2. 确保该组合内所有元素成员的层级是连续的，具体操作为：

   - 先获取到该组合内最上层元素的层级

   * 将本次需要组合的元素从新元素列表中移除

   * 根据最上层元素的层级位置，将需要组合的元素列表一起插入到新元素列表中合适的位置

3. 确保组合元素层级连续的原因：在调节元素层级位置关系的时候，需要检查**需要上移的元素** ***上一层级元素***是否是组合元素。若是组合元素，需要越过所有组合元素，再将该元素插入到组合元素的后面。

## 1.6 文件的导入

导入的文件只支持`.pptist`为后缀名的文件，其导入的实现为：首先导出的文件格式要是`.pptist`格式的，实质就是将幻灯片里面的数据经过加密后输出到文件里面再进行保存。而导入的`.pptist`文件，实质就是利用`FileReader`读取选中的文件，将加密的字符串（读取后文件的内容）进行解密后添加到`slideStore`中进行状态管理。

## 1.7 文件的导出

`FileSaver.js`是一个用于在客户端保存文件的解决方案，它是HTML5版本的`saveAs()` `FileSaver`实现，支持大多数主流的浏览器。它非常适合在客户端生成文件的Web应用程序。`FileSaver.saveAs`方法支持三个参数，第一个参数表示它支持`Blob/File/Url`三种类型，第二个参数表示文件名（可选）

`Bolb()`返回一个新创建的 `Blob` 对象，其内容**由参数中给定的数组拼接组成**。

1. 导出为`.pptist`：该后缀名为本应用特定的后缀名，实质就是将幻灯片的数据经过加密输出到一个文件里面。

   ```ts
   // 导出pptist文件（特有 .pptist 后缀文件）
   const exportSpecificFile = (_slides: Slide[]) => {
     // Blob 对象表示一个不可变、原始数据的类文件对象。
     const blob = new Blob([encrypt(JSON.stringify(_slides))], { type: '' })
     saveAs(blob, 'pptist_slides.pptist')
   }
   ```

2. 导出为`.json`：该类型文件实质就是直接将幻灯片的数据（json数据格式）输出到json文件。

   ```ts
   // 导出JSON文件
   const exportJSON = () => {
     const blob = new Blob([JSON.stringify(slides.value)], { type: '' })
     saveAs(blob, 'pptist_slides.json')
   }
   ```

3. 导出为`.png/.jepg`：`html-to-image`是一个使用`HTML5 canvas`和`SVG`**从DOM节点生成图像的工具**。它可以将`DOM`节点转换为图像，使用户**可以将网页的一部分或整个网页保存为图像**。

   除了`html-to-image`之外，还有其他一些工具可以将DOM节点转换为图像，如`html2canvas`和`dom-to-image`。这些工具的主要**区别在于它们使用的技术和生成图像的质量**。`html2canvas`使用`Canvas`元素将`DOM`节点转换为图像，而`dom-to-image`使用`SVG`元素将`DOM`节点转换为图像。因此，`dom-to-image`在生成图像时可以保留更高的分辨率和更好的质量，但在处理大型`DOM`时可能会更慢。**html2canvas则更适合处理较小的DOM，因为它可以生成更快的图像**。

4. 导出为`.pptx`：`pptxgenjs`是一个使用`JavaScript`生成`Microsoft PowerPoint`演示文稿的库。它可以在浏览器和Node.js环境中使用。您可以使用它来**创建幻灯片，添加文本和图像，设置样式和布局，然后将其导出为PPTX文件**。

   `pptxgenjs`能够实现大多数基本元素的导出，但还有非常多的缺陷需要一点点完善。同时需要知晓的是：1、该功能依赖 `pptxgenjs`，对于该库本身无法实现的部分（如动画），本项目也无能为力；2、导出功能的目标只是【导出样式尽可能一致的元素】，而不是一比一将网页还原到PPT，一些样式差异是必然存在的。

5. 导出为`.pdf`：

   - `window.print()`浏览器打印是一个非常成熟的东西，直接调用`window.print()`或者`document.execCommand('print')`达到打印及保存效果。
   - `html2canvas + jspdf`，使用`html2canvas`将使用`canvas`将页面转为`base64`图片流，并插入`jspdf`插件中，保存并下载pdf。

## 1.8 SVG

1. <defs>元素：SVG允许我们定义以后需要重复使用的图形元素。建议把所有需要再次使用的引用元素定义在<defs>元素里面，在<defs>元素中定义的图形元素不会直接呈现。你可以在你的视口的任意地方利用 <use>元素呈现这些元素。
2. <g>元素是用来组合对象的容器。添加到<g>元素的属性会被其所有的子元素继承。
3. <path>元素：用来定义形状的通用元素，所有的基本形状都可以用 path 元素来创建。

   - *d属性*定义了一个要绘制的路径。

   - *vector-effect属性*指明绘制对象时要使用的矢量效果。在任何其他合成操作（如滤镜，蒙版和剪辑等）之前，都要应用矢量效果。
   - *stroke-linecap属性*制定了在开放子路径被设置描边的情况下，用于开放自路径两端的形状。
   - *stroke-linejoin属性*指明路径的转角处使用的形状或者绘制的基础形状。
   - *stroke属性*定义了给定图形元素的外轮廓的颜色，它的默认值是none。
   - *stroke-dasharray属性*可控制用来描边的点划线的图案范式。
   - *marker-start属性*将在给定形状的起始顶点绘制的箭头或者多边形标记。
   - *marker-end属性*将在给定形状的最终顶点绘制的箭头或者多边形标记。
4. 非专业设计人士可以用该应用绘制基本形状：https://github.com/pipipi-pikachu/svgPathCreator

## 1.9 依赖注入

定义：一个父组件相对于其所有的后代组件，会作为**依赖提供者**。任何后代的组件树，无论层级有多深，都可以**注入**由父组件提供给整条链路的依赖。

**1. provide()**：提供一个值，可以被后代组件注入。

```ts
function provide<T>(key: InjectionKey<T> | string, value: T): void
```

1. `provide()` 接受两个参数：第一个参数是**要注入的 key**，可以是一个字符串或者一个 symbol；第二个参数是**要注入的值**。
2. 当使用 TypeScript 时，key 可以是一个被类型断言为 `InjectionKey` 的 symbol。`InjectionKey` 是一个 Vue 提供的工具类型，继承自 `Symbol`，可以用来同步 `provide()` 和 `inject()` 之间值的类型。
3. 与注册生命周期钩子的 API 类似，`provide()` 必须在组件的 `setup()` 阶段同步调用。

**2. inject()**：注入一个由祖先组件或整个应用 (通过 `app.provide()`) 提供的值。

```ts
// 没有默认值
function inject<T>(key: InjectionKey<T> | string): T | undefined

// 带有默认值
function inject<T>(key: InjectionKey<T> | string, defaultValue: T): T

// 使用工厂函数
function inject<T>(
  key: InjectionKey<T> | string,
  defaultValue: () => T,
  treatDefaultAsFactory: true
): T
```

1. 第一个参数是**注入的 key**。Vue 会遍历父组件链，通过匹配 key 来确定所提供的值。如果父组件链上多个组件对同一个 key 提供了值，那么离得更近的组件将会“覆盖”链上更远的组件所提供的值。如果没有能通过 key 匹配到值，`inject()` 将返回 `undefined`，除非提供了一个默认值。
2. 第二个参数是**可选的，即在没有匹配到 key 时使用的默认值**。它也可以是一个工厂函数，用来返回某些创建起来比较复杂的值。如果默认值本身就是一个函数，那么你必须将 `false` 作为第三个参数传入，表明这个函数就是默认值，而不是一个工厂函数。
3. 与注册生命周期钩子的 API 类似，`inject()` 必须在组件的 `setup()` 阶段同步调用。
4. 当使用 TypeScript 时，key 可以是一个类型为 `InjectionKey` 的 symbol。`InjectionKey` 是一个 Vue 提供的工具类型，继承自 `Symbol`，可以用来同步 `provide()` 和 `inject()` 之间值的类型。

**在项目中的缩略图组件中provide了一个缩放比例scale（缩略图大小 / VIEWPORT_SIZE）给后代组件（遍历元素时需要用）**。

```ts
// props.size 是缩略图需要展示的宽度
const scale = computed(() => props.size / VIEWPORT_SIZE)
provide(injectKeySlideScale, scale) // injectKeySlideScale：Symbol值的key
```

## 1.10 prosemirror

**！！！？？？超级难点，自定义`node`，`marks`，`EditorView.state.dispatch`后续只能在掘金上看人家的文章和在官网上慢慢摸索**

**1. prosemirror-state**：描述编辑器整体状态，包括文档数据、选择等。一个 state 有很多内建的字段，同时可以通过 plugins 来定义额外的字段。

**2. prosemirror-view**：UI组件，用于将编辑器状态展现为可编辑的元素，处理用户交互。

**3. prosemirror-commands**：该模块提供了很多基本的编辑commands, 包括在编辑器中按照你的期望映射 enter 和 delete 按键的行为，即提供了一系列命令函数，如换行的函数、删除的函数、加粗的函数等。这些命令大多数用来绑定按键以及定义菜单项。

**4. prosemirror-keymap**：该模块可以将键名映射到commands提供的命令函数，例如，将enter键映射到commands里的换行函数。

**5. prosemirror-model**：定义编辑器的文档模型，用来描述编辑器内容的数据结构。

**6. prosemirror-history**：该模块实现了 redo/undo 操作。

**7. prosemirror-inputrules**：该模块可以**配置匹配规则**，当我们输入的文本符合条件时，可以替换成别的文本或者节点，或者用 `transaction` 做更复杂的事情。它内置一些 `inputrule`，比如 `emDash`，**连续输入两个短横杠**会替换成**一个 长横杠**，我们想要实现的 `Markdown` 是像 `Typora` 的那种，输入* *hello** 自动变成 **hello** ，则需要借助 `prosemirror-inputrules` 。

**8. prosemirror-schema-basic**：该模块定义了一个简单的 schema。你可以直接拿来使用，或者扩展它，亦或者仅仅是抄其中的一些节点和 mark 的配置对象然后应用到新的 schema 中。

**9. prosemirror-schema-list**：该模块导出了列表相关的 schema 元素和命令。命令假设列表是可以被嵌套的，以及限制列表项的第一个元素必须为普通段落元素。

```ts
import { EditorState } from 'prosemirror-state'
import { EditorView } from 'prosemirror-view'
import { Schema, DOMParser } from 'prosemirror-model'
import { buildPlugins } from './plugins/index'
import { schemaMarks, schemaNodes } from './schema'

// 先创建schema（数据的规范标准），类似于约定了数据协议
const schema = new Schema({
  nodes: schemaNodes, // 扩展了prosemirror-schema-basic中的node
  marks: schemaMarks // 扩展了prosemirror-schema-basic中的mark
})
// 创建了一个DOM元素
export const createDocument = (content: string) => {
  const htmlString = `<div>${content}</div>`
  const parser = new window.DOMParser()
  const element = parser.parseFromString(htmlString, 'text/html').body.firstElementChild
  // DOMParser就是解析 DOM 元素的，其核心作用就是将元素内容同步到状态中，准确的说是 state 中的 doc 属性。
  return DOMParser.fromSchema(schema).parse(element as Element)
}

export const initProsemirrorEditor = (dom: Element, content: string, props = {}) => {
  return new EditorView(dom, { // 其次创建了state
    state: EditorState.create({
      doc: createDocument(content), // 创建一个DOM元素
      plugins: buildPlugins(schema) // plugins是自定义的
    }),
    ...props // 创建view时的prop
  })
}
```

初始化的流程：先是创建文档数据的规范标准，类似约定了数据协议。其次创建了 `state`，`state` 是需要满足 `schema` 规范的。最后根据 `state` 创建了 `view`，`view` 就是最终展现在用户面前的富文本编辑器UI。因为初始化的时候还没有用户操作的介入，所以并不涉及 `command` 也就是 `transform` 的引入。

**自定义插件**

```ts
import { keymap } from 'prosemirror-keymap'
import { Schema } from 'prosemirror-model'
import { history } from 'prosemirror-history'
import { baseKeymap } from 'prosemirror-commands'
import { dropCursor } from 'prosemirror-dropcursor'
import { gapCursor } from 'prosemirror-gapcursor'

import { buildKeymap } from './keymap'
import { buildInputRules } from './inputrules'

export const buildPlugins = (schema: Schema) => {
  return [
    buildInputRules(schema), // 匹配输入规则如输入**hello**
    keymap(buildKeymap(schema)), // 绑定键盘按键与prosemirror-commands功能函数的映射关系
    keymap(baseKeymap), // 一个基本的按键映射，包含不特定于任何 schema 的按键绑定，如enter、delete
    dropCursor(),
    gapCursor(), // 创建一个 gap 光标插件
    history() // 返回一个插件以使编辑器撤销历史可用，该插件将会追踪撤销和重做的操作栈
  ]
}
```

**遍历TextElement流程**

1. 在遍历一个text文本元素时，监测**富文本编辑元素（div）的父元素**的大小变化，因为当富文本编辑元素的宽度一定时，一行的宽度容纳不了这么多的字数从而会进行自动换行，此时富文本元素的高度则会发生变化，其父元素的高度也会发生变化，但是text文本元素的操作框（实质是四个div组成的，鼠标聚焦到该元素时则显示）与富文本编辑元素并**不存在嵌套关系**，所以需要监测（利用`ResizeObserver`进行元素的监测）富文本编辑元素的父元素，并**通知操作框做出响应的高度改变**。

2. 在`onMounted()`中将富文本编辑元素传入`initProsemirrorEditor()`中：

   ```ts
   onMounted(() => {
     // 返回一个EditorView对象，用户编辑就是基于EditorView实例对象进行操作
     editorView = initProsemirrorEditor((editorViewRef.value as Element), textContent.value, {
       // handleDOMEvents对象，键是 DOM 事件名，值是事件处理函数。事件处理函数将会先于 ProseMirror 处理任何发生在可编辑 DOM 元素上的事件之前调用。
       handleDOMEvents: {
         focus: handleFocus,
         blur: handleBlur,
         keydown: handleKeydown,
         click: handleClick, // 当富文本编辑元素被click时，调用handleClick
         mouseup: handleMouseup
       },
       editable: () => props.editable
     })
     if (!props.autoFocus) editorView.focus() 
   })
   ```

## 1.11 插入图片

1. 将要插入的图片转化成base64字符串后再进行渲染。

   ```ts
   export const getImageDataURL = (file: File): Promise<string> => {
     return new Promise(resolve => {
       // FileReader 对象允许 Web 应用程序异步读取存储在用户计算机上的文件（或原始数据缓冲区）的内容。
       const reader = new FileReader()
       // 一旦完成读取，result属性中将包含一个data: URL格式的Base64字符串以表示所读取文件的内容。
       reader.readAsDataURL(file)
       // load事件在整个页面及所有依赖资源如样式表和图片都已完成加载时触发
       reader.addEventListener('load', () => {
         // reader.result：文件的内容，该属性仅在读取操作完成后才有效。
         resolve(reader.result as string)
       })
     })
   }
   ```

2. 获取图片的宽高

   ```ts
   export const getImageSize = (src: string): Promise<ImageSize> => {
     return new Promise(resolve => {
       const img = document.createElement('img')
       img.src = src
       img.style.opacity = '0'
       document.body.appendChild(img)
   
       img.onload = () => {
         // img.clientWidth 返回img元素的内部宽度
         const imgWidth = img.clientWidth
         const imgHeight = img.clientHeight
   
         img.onload = null
         img.onerror = null
   
         document.body.removeChild(img)
         resolve({ width: imgWidth, height: imgHeight })
       }
   
       img.onerror = () => {
         img.onload = null
         img.onerror = null
       }
     })
   }
   ```

3. 在Toolbar中选择裁剪的形状时，点击时获取到形状的path路径，然后在<img>的父元素应用`clip-path`属性进行裁剪。

## 1.12 对齐吸附线

1. 所谓对齐吸附线，就是当**托拽的元素** **靠近画布中的其他元素**时或**对齐其他元素的水平和垂直中线**时，所显示出来的线条，作用是可以对齐其他元素的位置，使得元素之间排列更加整齐。

2. 首先收集此页面**每个元素（被旋转过的元素和线条元素除外）和画布可视区域**的水平对齐线`horizontalLines`（顶线、水平中线、底线）和垂直对齐线`verticalLines`（左线、垂直中线、右线）。

   然后将收集到的对齐吸附线与正在拖动的元素位置范围做对比，二者的差值小于设定的值时执行自动校正。对比的方法就是元素拖拽时记录下元素当前六条线的位置，利用两个for循环分别遍历水平`horizontalLines`线条数组和垂直`verticalLines`线条数组（水平垂直各三条），符合**对应的差值小于设定值**的线条push到`alignmentLines`数组中，最后将该数据进行遍历操作显示在页面中。

## 1.13 全屏

1. 全屏检测函数，是否支持全屏

   ```js
   // 支持全屏则返回true，否则返回false
   export function isFullScreen() {
     let isFull =
       window.fullScreen ||
       document.fullscreenEnabled ||
       document.webkitIsFullScreen ||
       document.msFullscreenEnabled;
    
     //to fix : false || undefined == undefined
     if (isFull === undefined) isFull = false;
     return isFull;
   }
   ```

2. 开启全屏和取消全屏

   ```js
   // 开启全屏
   export function enterFullScreen() {
     let docElm = document.documentElement;
     //W3C
     if (docElm.requestFullscreen) {
       docElm.requestFullscreen();
     }
     //FireFox
     else if (docElm.mozRequestFullScreen) {
       docElm.mozRequestFullScreen();
     }
     //Chrome
     else if (docElm.webkitRequestFullScreen) {
       docElm.webkitRequestFullScreen();
     }
   }
    
   // 取消全屏
   export function exitFullscreen() {
     if (document.exitFullscreen) {
       document.exitFullscreen();
     } else if (document.mozCancelFullScreen) {
       document.mozCancelFullScreen();
     } else if (document.webkitCancelFullScreen) {
       document.webkitCancelFullScreen();
     } else if (document.msExitFullscreen) {
       document.msExitFullscreen();
     }
   }
   ```

3. 判断是否全屏

   ```js
   export const isFullscreen = () => {
     // 返回当前文档中正在以全屏模式显示的Element节点，如果没有使用全屏模式，则返回null。
     const fullscreenElement =
       document.fullscreenElement ||
       document.mozFullScreenElement ||
       document.webkitFullscreenElement ||
       document.msFullscreenElement ||
       document.webkitCurrentFullScreenElement
     // 因为此函数需要返回的是Boolean值，而不是元素节点，故需要“!!”进行转换
     return !!fullscreenElement
   }
   ```

# 2 知识点

## 2.1 遍历对象的方法

**1 for…in**

`for...in`主要用于循环对象属性。循环中的代码每执行一次，就会对对象的属性进行一次操作。语法如下：

```js
for (let i in obj){
  // 执行的代码块
}
```

其中两个参数：

- i：必须。指定的变量可以是数组元素，也可以是**对象的属性**
- obj：必须。指定的**迭代的对象**

```js
let obj={a:1,b:2,c:3}

for (let i in obj){
  console.log('键名：',i)
  console.log('键值：',obj[i])
}
```

`for...in` 方法不仅会遍历当前对象的可枚举属性，还会遍历其原型链上的属性

**2 三个Object**

这三个方法都用来遍历对象，它会**返回一个由给定对象的自身可枚举属性(不含继承的和Symbol属性)组成的数组**，数组元素的排列顺序和正常循环遍历该对象时返回的顺序一致，三个元素返回的值分别如下：

- `Object.keys()`：返回包含对象键名的数组
- `Object.values()`：返回包含对象键值的数组
- `Object.entries()`：返回包含对象键名和键值的数组

```js
let obj={
 id:1,
 name:'hello',
 age:18
}

console.log(Object.keys(obj)) //['id','name','age']
console.log(Object.values()) //[1,'hello',18]
console.log(Object.entries()) //[['id',1],['name','hello'],['age',18]]
```

- `Object.keys()`方法返回的数组中的值都是字符串，也就是说不是字符串的key值会转化为字符串
- 结果数组中的属性值都是对象本身可枚举的属性，不包括继承来的属性

**3 getOwnPropertyNames方法**

`Object.getOwnPropertyNames()`方法与`Object.keys()`类似，也是接受一个对象作为参数，返回一个数组，包含了该对象自身的所有属性名。但它不能返回不可枚举的属性。

```js
let a=['hello', 'word']

Object.keys(a) //['0','1']
Object.getOwnPropertyNames(a) //['0','1','length']
```

这两个方法都可以计算对象中属性的个数：

```js
let a={0:'a',1:'b',2:'c'}

Object.getOwnPropertyNames(a) //['0','1','2']

Object.keys(a).length //3

Object.getOwnPropertyNames(a).length //3
```

**4 getOwnPropertySymbols方法**

`Object.getOwnPropertySymbols()`方法返回对象自身的Symbol属性组成的数组，不包括字符串属性：

```js
let obj={a:1}

//给对象添加一个不可枚举的Symbol属性
Object.getOwnPropertySymbols(obj,{
  [Symbol('zhu')]:{
    value: 'Symbol zhu',
    enumerable: false
  }
})

//给对象添加一个可枚举的Symbol属性
obj[Symbol('yu')]='Symbol yu'

Object.getOwnPropertySymbols(obj).forEach(key=>{
  console.log(obj[key]) //Symbol zhu  Symbol yu
})

```

**5 Reflect.ownKeys方法**

`Reflect.ownKeys()`返回一个数组，包含对象自身的属性。它和`Object.keys()`类似，`Object.keys()`返回属性key，但是不包括不可枚举的属性，而`Reflect.ownKeys()`会返回所有属性key：

```js
let obj={
  a:1,
  b:2
}

Object.defineProperty(obj,'method',{
  value:function(){
     alert('non enumerable property')
  },
  enumerable:false
})

console.log(Object.keys(obj)) //['a','b']

console.log(Reflect.ownKeys(obj))  //['a','b','method']
```

- `Object.keys()`：相当于返回对象属性数组
- `Reflect.ownKeys()`：相当于`Object.getOwnPropertyNames(obj).`concat(`Object.getOwnPropertySymbols(obj)`)

| 对象方法                       | 遍历基本属性 | 遍历原型链 | 遍历不可枚举属性 | 遍历Symbol |
| ------------------------------ | ------------ | ---------- | ---------------- | ---------- |
| for…in                         | 是           | 是         | 否               | 否         |
| Object.keys()                  | 是           | 否         | 否               | 否         |
| Object.getOwnPropertyNames()   | 是           | 否         | 是               | 否         |
| Object.getOwnPropertySymbols() | 否           | 否         | 否               | 是         |
| Reflect.ownKeys()              | 是           | 否         | 是               | 是         |

## 2.2 自定义插件

一个插件可以是一个拥有 `install()` 方法的**对象**，也可以直接是一个**安装函数本身**。安装函数会接收到安装它的[应用实例](https://cn.vuejs.org/api/application.html)和传递给 `app.use()` 的额外选项作为参数：

```js
// 1. 定义plugin.js
import { App } from 'vue' // TS中引入类型定义
const myPlugin = {
  install(app: App, options) {
    // 配置此应用
  }
}

// 2. 使用main.js
import plugin from './plugin.js'
app.use(plugin)
```

插件没有严格定义的使用范围，但是插件发挥作用的常见场景主要包括以下几种：

1. 通过 `app.component()` 和 `app.directive()` 注册一到多个全局组件或自定义指令。
2. 通过 `app.provide()`使一个资源可被注入进整个应用。
3. 向 `app.config.globalProperties`中添加一些全局实例属性或方法
4. 一个可能上述三种都包含了的功能库（例如 vue-router）。

## 2.3 自定义指令

1. 目的：自定义指令主要是为了重用涉及普通元素的底层 DOM 访问的逻辑。
2. 一个自定义指令由**一个包含类似组件生命周期钩子的对象**来定义。钩子函数**会接收到指令所绑定元素作为其参数**。

## 2.4 虚拟DOM

1. 虚拟 DOM：虚拟 DOM 是一种编程概念，即将目标所需的 UI 通过数据结构“虚拟”地表示出来，保存在内存中，然后将真实的 DOM 与之保持同步。
2. 挂载：一个运行时渲染器将会遍历整个虚拟 DOM 树，并据此构建真实的 DOM 树。这个过程被称为**挂载** (mount)。
3. 更新：如果我们有两份虚拟 DOM 树，渲染器将会有比较地遍历它们，找出它们之间的区别，**并应用这其中的变化到真实的 DOM** 上。这个过程被称为**更新** (patch)
4. 虚拟 DOM 的好处：虚拟 DOM 带来的主要好处是它让开发者能够灵活、声明式地创建、检查和组合所需 UI 的结构，同时**只需把具体的 DOM 操作留给渲染器去处理**。
5. 自定义指令、`createVNode()`、`render()`

## 2.5 emitter

1. 由于vue3开发中没有了EventBus跨组件通信，可以使用一个迷你库`mitt`这个替代方案，原理还是EventBus。

2. 基本使用

   ```js
   // 可以在项目目录utils下封装一个event.js
   import mitt from 'mitt'
   const mitt = mitt()
   export default mitt 
   ```

   ```vue
   // 组件 A
   <script setup>
   import mitter from '@/utils/event.js'
   function handleChange(obj) {mitter.emit('search-change', obj);
   }
   </script>
   
   // 组件 B 
   <script setup> import mitter from '@/utils/event.js'
   import { onUnmounted ,onMounted} from 'vue'
   // 监听
   onMounted(()=>{ mitter.on('search-change', (obj)=> { } })
   // off 监听 后面的事件是可选的可以不写
   onUnmounted(()=>{ mitter.off('search-change')}) </script> 
   
   ```

3. 本项目中使用

   ```ts
   // @/src/utils/emtter.ts
   import mitt, { Emitter } from "mitt"
   
   export const enum EmitterEvents {
     RICH_TEXT_COMMAND = 'RICH_TEXT_COMMAND',
     OPEN_CHART_DATA_EDITOR = 'OPEN_CHART_DATA_EDITOR',
     OPEN_LATEX_EDITOR = 'OPEN_LATEX_EDITOR'
   }
   
   export interface RichTextAction {
     command: string
     value?: string
   }
   
   export interface RichTextCommand {
     target?: string
     action: RichTextAction | RichTextAction[]
   }
   
   type Events = {
     [EmitterEvents.RICH_TEXT_COMMAND]: RichTextCommand
     [EmitterEvents.OPEN_CHART_DATA_EDITOR]: void
     [EmitterEvents.OPEN_LATEX_EDITOR]: void
   }
   
   const emitter: Emitter<Events> = mitt<Events>()
   
   export default emitter
   ```

# 3 配置

## 1 any类型出错

1. **问题**： 元素隐式具有 “any“ 类型，因为类型为 “string“ 的表达式不能用于索引类型 “Object“。 在类型 “Object“ 上找不到具有类型为 “string“ 的参数的索引签名。

2. **描述：** 在写代码的时候，对一个对象做了一个for…in循环，然后取到了其每一个key对应的value值，但是写完之后发现[Typescript](https://so.csdn.net/so/search?q=Typescript&spm=1001.2101.3001.7020)报错了，错误内容就是如题，有点奇怪，特此去了解一下。

   ```js
   for (const key in obejct) {
   	// 处理...
   	obejct[key]
   	....
   }
   ```

3. **解决：**
   原谅我报错都没有看明白，查了一下之后才知道，原来key值的类型不是string，在javascript中是默认给你转好的，而在Typescript中则不是，因此**要么转**，**要么声明**，**要么忽略**。

   - 方案一：忽略

     在tsconfig.json中compilerOptions里面新增忽略的代码，如下所示，添加后则不会报错

     `"suppressImplicitAnyIndexErrors": true`

   - 方案二：声明

     在定义的Interface里对其进行声明，如下所示，声明过后，也不会再报错

     ```ts
     interface DAMNU_ENABLE {
         ....
         [key: string]: boolean, // 字段扩展声明
     }; 
     [key: string]: boolean, // 字段扩展声明 声明之后可以用方括号的方式去对象里边的值
     ```

   - 方案三：对其使用keyof进行判断

     ```ts
     export function isValidKey(
         key: string | number | symbol,
         object: object
     ): key is keyof typeof object {
         return key in object;
     }
     ```

     定义一个函数：isValidKey()，然后对需要使用到的地方进行一次判断

     ```javascript
     for (const key in obejct) {
     	if(isValidKey(key,obejct)){
     		// 处理...
     		obejct[key]
     		....
     	}
     }
     ```













