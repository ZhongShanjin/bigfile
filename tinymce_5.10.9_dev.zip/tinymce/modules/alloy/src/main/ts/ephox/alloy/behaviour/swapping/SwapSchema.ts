import { FieldSchema } from '@ephox/boulder';

export default [
  FieldSchema.required('alpha'),
  FieldSchema.required('omega')
];
