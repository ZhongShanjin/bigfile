import { FieldSchema } from '@ephox/boulder';

export default [
  FieldSchema.required('onPinch'),
  FieldSchema.required('onPunch')
];
