import { Fun } from '@ephox/katamari';

const debug = (): void => {
  // eslint-disable-next-line no-debugger
  debugger;
};

const pass = Fun.noop;

export {
  debug,
  pass
};
