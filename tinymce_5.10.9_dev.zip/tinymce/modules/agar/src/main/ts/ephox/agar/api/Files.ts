import { createFile, createFileFromString } from '../file/Files';

export {
  createFile,
  createFileFromString
};
